import React from "react";

function EstimateDonePage() {
  return <div>EstimateDonePage</div>;
}

export default EstimateDonePage;
