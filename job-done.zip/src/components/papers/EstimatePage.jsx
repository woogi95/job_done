import React from "react";

function EstimatePage() {
  return <div>EstimatePage</div>;
}

export default EstimatePage;
