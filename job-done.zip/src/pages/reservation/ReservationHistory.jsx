import Estimate from "../../components/papers/Estimate";
function ReservationHistory() {
  return (
    <div>
      예약내역페이지
      {/* 견적서인데 일단 둘곳 없어서 둠 스웨거랑 폴더랑 꼬임 */}
      <Estimate />
    </div>
  );
}

export default ReservationHistory;
