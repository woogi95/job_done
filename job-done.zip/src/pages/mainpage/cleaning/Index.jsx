import React from "react";

function CleaningPage() {
  return <div>CleaningPage</div>;
}

export default CleaningPage;
