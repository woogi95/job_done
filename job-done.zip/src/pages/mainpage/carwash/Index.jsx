import React from "react";

function CarWashPage() {
  return <div>CarWashPage</div>;
}

export default CarWashPage;
