import React from "react";

function MovePage() {
  return <div>MovePage</div>;
}

export default MovePage;
