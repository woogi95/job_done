import React from "react";

function ReservationPage() {
  return <div>ReservationPage</div>;
}

export default ReservationPage;
