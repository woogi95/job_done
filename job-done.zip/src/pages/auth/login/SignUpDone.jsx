import React from "react";

function SignUpDone() {
  return <div></div>;
}

export default SignUpDone;
