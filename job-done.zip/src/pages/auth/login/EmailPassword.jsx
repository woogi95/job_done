import React from "react";

function EmailPassword() {
  return <div>EmailPassword</div>;
}

export default EmailPassword;
