import React from "react";

function BusinessSignUp() {
  return <div>BusinessSignUp</div>;
}

export default BusinessSignUp;
