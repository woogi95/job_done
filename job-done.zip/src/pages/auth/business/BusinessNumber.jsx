import React from "react";

function BusinessNumber() {
  return <div>BusinessNumber</div>;
}

export default BusinessNumber;
