import React from "react";

function Reservation() {
  return <div>Reservation</div>;
}

export default Reservation;
