import React from "react";

function Index() {
  return <div>일정관리</div>;
}

export default Index;
