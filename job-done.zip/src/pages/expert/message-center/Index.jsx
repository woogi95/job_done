import React from "react";

const Index = () => {
  return <div>메세지함 / 채팅</div>;
};

export default Index;
