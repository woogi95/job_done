import { Button, Form, Input } from "antd";
const ReviewEdit = () => {
  const initData = {};
  return (
    <div>
      <Form></Form>
    </div>
  );
};

export default ReviewEdit;
