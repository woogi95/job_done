import React, { useState } from "react";
import { useRecoilState } from "recoil";
import { reviewListState } from "../../../atoms/reviewAtom";

const ReviewView = () => {
  const [reviewData, setReviewData] = useRecoilState(reviewListState);
  const [reviewComment, setReviewComment] = useState();
  const initData = {
    reviewId: "",
    contents: "",
  };
  return (
    <div style={{ display: "block", padding: 10 }}>
      {/* 유저이름, 평점,날짜 */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          height: "100",
          fontSize: "20",
        }}
      >
        {/* 유저이름 */}
        <div>{reviewData.name}님의 리뷰</div>
        {/* 평점,날짜 */}
        <div></div>
      </div>
      {/* 사진 */}
      <div style={{ display: "flex" }}></div>
      {/* 유저리뷰 */}
      <div style={{ display: "block" }}>
        {/* 리뷰 */}
        <div style={{ display: "flex", width: "100%" }}></div>
        {/* 답글등록 버튼 */}
        <div>
          {isComments ? (
            <button>답글수정</button>
          ) : (
            <button onClick={() => {}}>답글 등록</button>
          )}
        </div>
      </div>
      {/* 답글등록 */}
      {commentResister ? (
        <div>
          {/* 답글입력 */}
          <Form
            initialValues={initData}
            onFinish={onsubmit}
            style={{ width: "100%" }}
          >
            <Form.item>
              <Input />
            </Form.item>
          </Form>
          {/* 삭제버튼/ 등록,수정 */}
          <div>
            <butoon></butoon>
            <butoon></butoon>
          </div>
        </div>
      ) : (
        ""
      )}
    </div>
  );
};

export default ReviewView;
