import React from "react";

function EditCompanyInfo() {
  return <div>EditCompanyInfo</div>;
}

export default EditCompanyInfo;
