import React from "react";

function CompanyInfo() {
  return <div>CompanyInfo</div>;
}

export default CompanyInfo;
