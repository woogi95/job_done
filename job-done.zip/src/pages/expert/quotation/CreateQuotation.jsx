import React from "react";

function CreateQuotation() {
  return <div>CreateQuotation</div>;
}

export default CreateQuotation;
