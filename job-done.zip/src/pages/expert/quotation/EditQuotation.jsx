import React from "react";

function EditQuotation() {
  return <div>EditQuotation</div>;
}

export default EditQuotation;
