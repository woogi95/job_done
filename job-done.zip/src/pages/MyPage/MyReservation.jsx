import React from "react";

function MyReservation() {
  return <div>MyReservation</div>;
}

export default MyReservation;
