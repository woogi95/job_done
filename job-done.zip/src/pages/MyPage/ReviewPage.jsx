import React from "react";
import MyPageLayout from "../../components/MyPageLayout";

function ReviewPage() {
  return (
    <MyPageLayout>
      <div>
        <div>ReviewPage</div>
      </div>
    </MyPageLayout>
  );
}

export default ReviewPage;
