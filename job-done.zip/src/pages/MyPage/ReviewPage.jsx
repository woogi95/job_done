import React from "react";

function ReviewPage() {
  return <div>ReviewPage</div>;
}

export default ReviewPage;
