import React from "react";

function UsageDetails() {
  return <div>UsageDetails</div>;
}

export default UsageDetails;
