import React from "react";

function MyMessage() {
  return <div>MyMessage</div>;
}

export default MyMessage;
