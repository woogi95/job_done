import styled from "@emotion/styled";

// 레이아웃(임시)
export const LayoutDiv = styled.div`
  max-width: 1280px;
  /* border: 1px solid #eee; */
  margin: 0 auto;
`;
