export const reservation = atom({
  key: "reservation",
  default: {},
});
