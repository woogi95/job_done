import { atom } from "recoil";

export const PortfolioListState = atom({
  key: "PortfolioListState",
  default: {},
});
